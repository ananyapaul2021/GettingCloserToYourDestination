# GettingCloserToTheDesiredDestination
Uploaded my latest college project.


Q. What my code is all about?
Ans: Well, it takes you to your destination(the destination that you will input).

Q. How? I mean anything unique of that sort?
Ans: Got you! Yes, its a bit different. What it will do is, given a source(your starting location) and destination(yours I mean) it will
     search for a location which is closer to your destination but the catch is, that particular location should be reacheable directly(or
     there is a direct path from your current location to that paticular location). That's how your current location is being updated
     and you finally reach your destination(if and only if there an actual route that exists else boom!).
     
     
     I hope that's all. Thank You. :)
